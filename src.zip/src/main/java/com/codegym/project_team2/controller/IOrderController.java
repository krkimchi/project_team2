package com.codegym.project_team2.controller;

import com.codegym.project_team2.model.Order;

public interface IOrderController {
    boolean save(Order order);
}
