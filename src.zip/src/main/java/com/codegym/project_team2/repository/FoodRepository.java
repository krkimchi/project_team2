package com.codegym.project_team2.repository;

import com.codegym.project_team2.model.Food;
import com.codegym.project_team2.util.BaseRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FoodRepository implements IFoodRepository{
    private final String MOST_ORDER = "select * from food order by ?";

    @Override
    public List<Food> getMostOrderedFoods() {
        List<Food> foodList = new ArrayList<>();
        Connection connection = BaseRepository.getConnectDB();
        try {
            PreparedStatement statement = connection.prepareStatement(MOST_ORDER);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return List.of();
    }

    @Override
    public List<Food> searchFood(String keyword) {
        return List.of();
    }
}
