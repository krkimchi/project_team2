package com.codegym.project_team2.repository;

import com.codegym.project_team2.model.Order;

public class OderRepository implements IOrderRepository{
    @Override
    public boolean save(Order order) {
        return false;
    }
}
